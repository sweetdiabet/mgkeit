![lol](/demo.png)
# Прототип системы управления аптекой (визуальный)

## Для работы необходимо наличие [Node.js 16.13.0 (LTS)](https://nodejs.org/en/)

## Установка при помощи консоли

```bash
# установка yarn (если не установлен)
$ npm install --global yarn

# копирование кода
$ git clone https://github.com/rogi27/AptekPomosh

# 1) открыть папку
$ cd AptekPomosh

# 2) установка зависимостей
$ yarn install

# 3) запуск для отладки по адресу localhost:3000
$ yarn dev

# создание готового проекта
$ yarn generate
```

Больше информации можно получить в [документации](https://nuxtjs.org).
