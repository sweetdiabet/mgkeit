import moment from 'moment'

import 'moment/locale/ru'

import 'moment-timezone'

moment.locale('ru')

moment.tz.setDefault('Europe/Moscow')

export default (ctx, inject) => {
  ctx.$moment = moment
  inject('moment', moment)
}
