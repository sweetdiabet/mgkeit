import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7be3cef7 = () => interopDefault(import('..\\pages\\admin\\index.vue' /* webpackChunkName: "pages/admin/index" */))
const _b8a67a52 = () => interopDefault(import('..\\pages\\films\\index.vue' /* webpackChunkName: "pages/films/index" */))
const _e6445520 = () => interopDefault(import('..\\pages\\account\\login.vue' /* webpackChunkName: "pages/account/login" */))
const _5bede113 = () => interopDefault(import('..\\pages\\account\\logout.vue' /* webpackChunkName: "pages/account/logout" */))
const _eccd2296 = () => interopDefault(import('..\\pages\\admin\\users\\index.vue' /* webpackChunkName: "pages/admin/users/index" */))
const _6b6b6e50 = () => interopDefault(import('..\\pages\\error\\permissions.vue' /* webpackChunkName: "pages/error/permissions" */))
const _3f28e202 = () => interopDefault(import('..\\pages\\films\\_id.vue' /* webpackChunkName: "pages/films/_id" */))
const _6bea25c9 = () => interopDefault(import('..\\pages\\sessions\\_id\\index.vue' /* webpackChunkName: "pages/sessions/_id/index" */))
const _43b3cbaf = () => interopDefault(import('..\\pages\\sessions\\_id\\order\\_seat.vue' /* webpackChunkName: "pages/sessions/_id/order/_seat" */))
const _a56249a4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _7be3cef7,
    name: "admin"
  }, {
    path: "/films",
    component: _b8a67a52,
    name: "films"
  }, {
    path: "/account/login",
    component: _e6445520,
    name: "account-login"
  }, {
    path: "/account/logout",
    component: _5bede113,
    name: "account-logout"
  }, {
    path: "/admin/users",
    component: _eccd2296,
    name: "admin-users"
  }, {
    path: "/error/permissions",
    component: _6b6b6e50,
    name: "error-permissions"
  }, {
    path: "/films/:id",
    component: _3f28e202,
    name: "films-id"
  }, {
    path: "/sessions/:id",
    component: _6bea25c9,
    name: "sessions-id"
  }, {
    path: "/sessions/:id?/order/:seat?",
    component: _43b3cbaf,
    name: "sessions-id-order-seat"
  }, {
    path: "/",
    component: _a56249a4,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
