<template>
  <div class="app">
    <div class="content">
      <Nuxt />
    </div>
  </div>
</template>

<style lang="scss">
body {
  @apply font-app font-medium bg-app-50;
}
</style>
