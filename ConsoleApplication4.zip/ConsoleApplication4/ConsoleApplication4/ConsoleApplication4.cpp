﻿#include "pch.h"
#include <iostream>

using namespace std;

int main() 
{
	setlocale(LC_ALL, "Russian");
	int N;
	cout << "Введите месяц: ";
	cin >> N;
	switch (N)
	{
	case 1: {cout << "Это зима!"; break; }
	case 2: {cout << "Это зима!"; break; }
	case 3: {cout << "Это весна!"; break; }
	case 4: {cout << "Это весна!"; break; }
	case 5: {cout << "Это весна!"; break; }
	case 6: {cout << "Это лето!"; break; }
	case 7: {cout << "Это лето!"; break; }
	case 8: {cout << "Это лето!"; break; }
	case 9: {cout << "Это осень!"; break; }
	case 10: {cout << "Это осень!"; break; }
	case 11: {cout << "Это осень!"; break; }
	case 12: {cout << "Это зима!"; break; }
	}

	system("pause>>void");
}